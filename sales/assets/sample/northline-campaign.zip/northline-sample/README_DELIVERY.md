# Campaign delivery

Review the approval summary first, then adapt copy and creative assets only after client/factual approval. This pack is editable and can be printed to PDF from a browser.

## Visual file formats

Every visual ships as SVG (the editable, infinitely scalable master) plus a pixel-perfect PNG twin at the same size — hero 1200×630, Instagram 1080×1080, favicon 512, social avatar 500, every logo and custom banner at its requested size. The main ad placements (hero, Instagram) also include a JPEG twin, ready to upload to Meta/Google/LinkedIn. Missing PNGs? Run `pip install resvg-py` and regenerate the campaign.
