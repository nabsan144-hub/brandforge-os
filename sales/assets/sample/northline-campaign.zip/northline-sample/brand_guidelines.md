# Northline Coffee — Brand Guidelines

> Generated with BrandForge OS — Review before publishing — High-end branding kit

## Brand
- **Name:** Northline Coffee
- **Industry:** Specialty Coffee
- **Tagline:** Northline Coffee — Specialty Coffee

## Logo Types (7 types from research)
- **Lettermark:** N — initials/monogram — best for long names, app icon, favicon, social avatar — IBM, CNN style — high reliability for embroidery, small sizes
- **Wordmark:** Northline Coffee styled — best for short memorable names — Google, Coca-Cola style — high print reliability
- **Combination:** Icon + text separable — most versatile — Burger King, Lacoste — works for website header, packaging, app icon, business card — **recommended for most brands**
- **Abstract:** Geometric non-literal — Pepsi, Nike — best for tech/AI, emotional brands
- **Pictorial:** Literal icon — Apple, Twitter — best for strong visual idea
- **Emblem:** Badge/seal — Starbucks, Harley — best for heritage, institutional

## Logo Usage
- **Primary:** `primary_logo.svg` — combination — use on website header, business cards, invoices
- **Reversed:** `reversed_logo.svg` — white on dark — use on dark backgrounds
- **Icon Only:** `icon_only.svg` — lettermark — use for social avatar (500x500), favicon (512x512), app icon — small spaces need compact recognition
- **Wordmark:** `wordmark.svg` — text only — use for document headers, when icon not needed
- **Clear Space:** Keep clear space around logo = height of letter N
- **Minimum Size:** 24px for icon, 120px for combination

## Colors
- **Primary #E8B54A:** Premium CTA — gold reserved for one accent — use for buttons, highlights
- **Secondary #0F172A:** Trust — navy — use for backgrounds, text
- **Accent (brand-derived):** Secondary CTA, links — hex in color_palette.json
- **Success Green #10B981:** Success states

## Typography
- **Headlines:** Instrument Serif italic + Geist Bold — premium studio identity
- **Body:** Geist 400/500 — system-ui fallback
- **Mono:** Geist Mono — for codes, badges

## Files Included
- `primary_logo.svg` — main combination logo
- `reversed_logo.svg` — white on dark
- `icon_only.svg` — lettermark for avatars
- `wordmark.svg` — text only
- `lettermark.svg`, `abstract_mark.svg`, `emblem.svg` — variations
- `favicon.svg` — 512x512 high-res favicon (generate PNGs 32x32, 16x16 from this)
- `social_avatar.svg` — 500x500 circle avatar
- `color_palette.json` — palette for devs
- `brand_guidelines.md` — this file
- `logo_usage.md` — placement guide

## Next Steps
1. Review all logos — check spelling, colors, readability at small sizes (16px favicon)
2. Generate PNGs from SVGs for platforms that need PNG: favicon 32x32, 16x16, social avatar 500x500 PNG
3. Test on light and dark backgrounds
4. For AI high-end variations, set `BRANDFORGE_IMAGE_ENDPOINT` to Replicate/Ideogram/DALL-E and use `generate_image` tool with prompt "minimal premium logo for Northline Coffee, flat vector, #E8B54A on #0F172A, transparent background, high-end"

> Template generated with BrandForge OS — Add your final logo selection before publishing.
