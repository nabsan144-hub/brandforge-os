# Northline Coffee — Logo Usage by Placement

| Placement | Best Logo Type | File | Why |
|---|---|---|---|
| Website header | Combination, Wordmark | primary_logo.svg, wordmark.svg | Brand name clear quickly |
| Social avatar | Lettermark, Abstract | icon_only.svg, social_avatar.svg (500x500) | Small circular/square needs compact |
| Favicon | Lettermark | favicon.svg (512x512) → generate 32x32, 16x16 PNG | Tiny spaces need extreme simplification |
| App icon | Lettermark, Abstract | icon_only.svg, abstract_mark.svg | Simple shapes at small sizes |
| Business card | Combination, Wordmark | primary_logo.svg | Pairs with contact details |
| Invoice/document | Wordmark | wordmark.svg | Clarity > decoration |
| Packaging | Combination, Emblem | primary_logo.svg, emblem.svg | Shelf presence |
| Merch (T-shirt) | Lettermark, Emblem | icon_only.svg, emblem.svg | Bold shapes hold up for screen print/embroidery |
| Social feed 1080x1080 | Combination | primary_logo.svg on hero_banner 1200x630 etc | Use with custom size banners |

- Lettermark high reliability for embroidery, screen print, debossing, laser engraving — bold shapes, limited colors
- Wordmark high for screen print, heat transfer — center chest, back
- Combination most versatile — design icon and wordmark to work independently from day one

> Generated with BrandForge OS — Review before publishing.
