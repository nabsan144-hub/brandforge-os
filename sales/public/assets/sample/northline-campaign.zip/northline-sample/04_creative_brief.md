# Creative Brief — Northline Coffee

## Objective
Turn the approved strategy into clear, brand-consistent campaign creative for People who enjoy a fresh coffee ritual.

## Approved customer benefits
- Fresh-roasted beans
- transparent origin information

## Visual direction
- Use the client’s saved primary and secondary brand colors.
- Keep the headline concise and the CTA visually obvious.
- Do not add unsupported statistics, awards, testimonials, prices, or before/after claims.
- Produce required channel sizes from the approved final copy.

## Strategy context
### Brand Strategy — Northline Coffee

**Positioning:** For People who enjoy a fresh coffee ritual, Northline Coffee is a Specialty Coffee choice built around Fresh-roasted beans, transparent origin information.
**Tone:** Executive, Bold, High-Converting
**Customer problem to validate:** Finding a food or drink option that fits your preferences and routine.
**Supplied proof (verify before use):** None supplied — do not invent proof
**Avoid:** No fabricated results or endorsements

> Template strategy based only on your brief. No market research was performed.
